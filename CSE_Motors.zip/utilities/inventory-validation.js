const { body, validationResult } = require("express-validator");
const utilities = require("./");
const invModel = require("../models/inventory-model");
const inventoryValidate = {};

/*************************************
 *  Add Classification Validation Rules
 **************************************/
inventoryValidate.addClassificationRules = () => {
  return [
    body("classification_name")
      .trim()
      .isAlphanumeric()
      .withMessage("Classification name must be alphanumeric without spaces or special characters."),
  ];
};

/*****************************************************************
 * Check data and return errors or continue to add classification
 *****************************************************************/
inventoryValidate.checkAddClassification = async (req, res, next) => {
  const { classification_name } = req.body;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const nav = await utilities.getNav();
    res.render("inventory/add-classification", {
      errors: errors.array(),
      title: "Add Classification",
      nav,
      messages: req.flash("notice"),
      classification_name,
    });
    return;
  }
  next();
};

/**********************************
 *  Add Inventory Validation Rules
 **********************************/
inventoryValidate.addInventoryRules = () => {
  return [
    body("inv_make").trim().isAlphanumeric().withMessage("Make is required and must be alphanumeric."),
    body("inv_model").trim().isAlphanumeric().withMessage("Model is required and must be alphanumeric."),
    body("inv_year").isInt({ min: 1900, max: 2100 }).withMessage("Year must be a valid number between 1900 and 2100."),
    body("inv_price").isFloat({ min: 0 }).withMessage("Price must be a positive number."),
    body("inv_description").trim().notEmpty().withMessage("Description is required."),
  ];
};

/*****************************************************************
 * Check data and return errors or continue to add inventory item
 *****************************************************************/
inventoryValidate.checkAddInventory = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const nav = await utilities.getNav();
    const classificationDropdown = await utilities.buildClassificationList(req.body.classification_id);
    res.status(400).render("inventory/add-inventory", {
      title: "Add Inventory Item",
      nav,
      classificationDropdown,
      messages: req.flash("notice"),
      errors: errors.array(),
      ...req.body,
    });
    return;
  }
  next();
};

module.exports = inventoryValidate;